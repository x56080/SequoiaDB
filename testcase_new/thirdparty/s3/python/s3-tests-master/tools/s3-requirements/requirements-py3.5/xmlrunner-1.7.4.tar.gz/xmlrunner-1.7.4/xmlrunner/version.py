# -*- coding: utf-8 -*-
"""
    xmlrunner.version
    ~~~~~~~~~~~~~~~~~

    Runtime library version information.

    :codeauthor: :email:`Pedro Algarvio (pedro@algarvio.me)`
    :copyright: © 2013 Pedro Algarvio.
    :license: LGPL, see LICENSE for more details.
"""

__version_info__ = (1, 7, 4)
__version__ = '.'.join(map(str, __version_info__))
